#ifndef __TCP_DEMO_H__
#define __TCP_DEMO_H__

#include "types.h"

void do_tcp_server(void);//TCP Server回环演示函数
void do_tcp_client(void);//TCP Clinet回环演示函数

#endif 


#ifndef __UDP_DEMO_H
#define __UDP_DEMO_H

#include "types.h"

extern uint16 udp_port;/*定义UDP的一个端口并初始化*/
void do_udp(void);

#endif 


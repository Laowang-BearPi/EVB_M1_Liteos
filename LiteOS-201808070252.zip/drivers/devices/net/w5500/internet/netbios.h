#ifndef __NETBIOS_H__
#define __NETBIOS_H__

void do_netbios(void);

#endif /* __NETBIOS_H__ */
